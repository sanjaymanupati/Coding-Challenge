import Topics from './components/Topics'

function App() {

  return (
    <div className="App">
      <Topics topic="react" />
    </div>
  );
}

export default App;
