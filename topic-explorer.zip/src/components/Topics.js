import { useQuery, gql } from '@apollo/client';
import Topic from './Topic';

const GET_TOPICS = gql`
  query GetTopicss($name: String!) {
    topic(name: $name){
      name
      relatedTopics(first: 10){
          id
          name,
          stargazerCount
      }
    }
  } 
`;

function Topics({ topic }) {
  const { loading, error, data } = useQuery(GET_TOPICS, {
    variables: { name: topic },
  });

  if (loading) return <p>Loading...</p>;
  if (error) return <p>Error :(</p>;

  return (
    <section>
      <h1>Related Topics to {topic}</h1>
      <ul>
        {data.topic.relatedTopics.map(({ id, name, stargazerCount }) => (
          <Topic key={id} name={name} stargazerCount={stargazerCount}/>
        ))}
      </ul>
    </section>
  )
}

export default Topics