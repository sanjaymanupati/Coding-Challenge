import { useState } from "react"
import Topics from "./Topics"

function Topic({ name, stargazerCount }) {
  const [showRelated, setShowRelated] = useState(false)
  return (
    <li onClick={() => setShowRelated(true)}>
      <h3>Topic Name: {name}</h3>
      <p>Stargazer Count: {stargazerCount}</p>
      {showRelated && <Topics topic={name} />}
    </li>
  )
}

export default Topic